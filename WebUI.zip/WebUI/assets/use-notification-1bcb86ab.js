import{I as o,J as n,bC as t}from"./index-51b823b5.js";function a(){const i=o(t,null);return i===null&&n("use-notification","No outer `n-notification-provider` found."),i}export{a as u};
